let isListening = false;
let recognition = new webkitSpeechRecognition();
recognition.continuous = true; 
// TURN ON REAL-TIME INTERIM RESULTS:
recognition.interimResults = true; 
recognition.lang = "en-US";

const btn = document.getElementById('startBtn');
const statusDiv = document.getElementById('status');
const transcriptDiv = document.getElementById('transcript');
const alternativeDiv = document.getElementById('alternative');
const historyList = document.getElementById('history-list');
const currentBox = document.getElementById('current-box');

// Instant trigger words to catch them mid-sentence!
const dangerKeywords = ["married", "kids", "pregnant", "salary", "age", "church", "religion", "disability", "arrested"];

btn.addEventListener('click', () => {
    if (!isListening) { recognition.start(); } 
    else { recognition.stop(); resetUI(); }
});

function resetUI() {
    isListening = false;
    btn.textContent = "▶️ Start Live Monitoring";
    btn.className = "";
    statusDiv.textContent = "Standby Mode...";
    currentBox.style.borderLeftColor = "#ccc";
}

recognition.onstart = function() {
    isListening = true;
    btn.textContent = "⏹️ Stop Monitoring";
    btn.className = "recording";
    statusDiv.textContent = "🟢 Listening to meeting...";
    currentBox.style.borderLeftColor = "#3b82f6";
    alternativeDiv.style.display = "none";
};

recognition.onresult = function(event) {
    let interimTranscript = '';
    let finalTranscript = '';

    for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
        } else {
            interimTranscript += event.results[i][0].transcript;
        }
    }

    // --- REAL-TIME MID-SENTENCE PREDICTION ---
    if (interimTranscript.length > 0) {
        transcriptDiv.innerHTML = `🗣️ <i>"${interimTranscript}..."</i>`;
        
        // If they say a danger word mid-sentence, flash a warning instantly!
        if (dangerKeywords.some(word => interimTranscript.toLowerCase().includes(word))) {
            statusDiv.textContent = "⚠️ WARNING: Pivot question now!";
            currentBox.style.borderLeftColor = "#fbbf24"; // Yellow
        } else {
            statusDiv.textContent = "Listening...";
            currentBox.style.borderLeftColor = "#3b82f6"; // Blue
        }
    }

    // --- FINAL SENTENCE AI ANALYSIS (Sent to FastAPI) ---
    if (finalTranscript.length > 0) {
        transcriptDiv.textContent = `🗣️ "${finalTranscript}"`;
        statusDiv.textContent = "⚙️ Finalizing AI Analysis...";
        
        fetch('http://127.0.0.1:8000/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: finalTranscript })
        })
        .then(response => response.json())
        .then(data => {
            if(historyList.children[0] && historyList.children[0].textContent.includes("No questions")) {
                historyList.innerHTML = "";
            }

            let historyItem = document.createElement("li");

            if (data.is_flagged) {
                statusDiv.textContent = `🚨 ILLEGAL: ${data.category}`;
                currentBox.style.borderLeftColor = "#ef4444"; 
                alternativeDiv.style.display = "block";
                alternativeDiv.innerHTML = `<b>💡 Say instead:</b><br>${data.safe_alternative}`;
                historyItem.innerHTML = `<span style="color:#ef4444; font-weight:bold;">🚨 Flagged:</span> "${finalTranscript}"`;
            } else {
                statusDiv.textContent = "✅ SAFE QUESTION";
                currentBox.style.borderLeftColor = "#10b981"; 
                alternativeDiv.style.display = "none";
                historyItem.innerHTML = `<span style="color:#10b981; font-weight:bold;">✅ Safe:</span> "${finalTranscript}"`;
            }
            historyList.prepend(historyItem);
        })
        .catch(err => {
            statusDiv.textContent = "❌ Connection Error";
        });
    }
};