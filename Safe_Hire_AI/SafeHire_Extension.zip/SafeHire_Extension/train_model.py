import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib

print("🚀 Initializing SafeHire AI Model Training...\n")

# 1. THE DATASET (Embedded directly from the HR Legal PDF to avoid file errors)
data = {
    "question": [
        "How long have you lived in this city?",
        "If hired, can you furnish proof of age?",
        "What is your date of birth?",
        "Are you younger than our regular retirement age?",
        "After employment, can you submit proof of the right to remain in or work in the U.S.?",
        "What is your first language?",
        "If you are not a U.S. citizen, do you have the legal right to remain permanently in the U.S.?",
        "Of what country are you a citizen?",
        "Are you prevented from lawfully becoming employed because of visa or immigration status?",
        "How would you perform this particular task?",
        "Do you have any physical, mental or sensory handicaps which might affect work performance or which should be considered in job placement?",
        "Do you have any handicaps?",
        "Can you meet the specified work schedule?",
        "What are your child-care arrangements?",
        "Do you plan to have children?",
        "Have you worked for this organization under a different name?",
        "Is any additional information relative to change of name necessary to enable a check on your work record?",
        "Are you a Miss, Mrs., or Ms.?",
        "What is your maiden name?",
        "By whom were you referred for a position here?",
        "What is your religious denomination or affiliation?",
        "What problems did you have on previous jobs, what did you like or dislike?"
    ],
    # 0 = Legal/Safe, 1 = Illegal/Flagged
    "label": [0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0]
}

df = pd.DataFrame(data)
print(f"📊 Loaded training dataset with {len(df)} HR questions.")

# 2. TEXT PROCESSING
print("⚙️ Vectorizing text using TF-IDF...")
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['question'])
y = df['label']

# 3. TRAIN THE MODEL
print("🧠 Training Context-Aware NLP Classifier (Logistic Regression)...")
model = LogisticRegression()
model.fit(X, y)

# 4. SAVE THE MODEL
joblib.dump(model, 'safehire_model.pkl')
joblib.dump(vectorizer, 'tfidf_vectorizer.pkl')

print("\n✅ SUCCESS: Model trained and saved!")
print("📁 Generated: 'safehire_model.pkl' and 'tfidf_vectorizer.pkl'")